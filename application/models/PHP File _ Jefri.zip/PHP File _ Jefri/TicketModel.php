<?php

class TicketModel extends CI_Model {

    public function create() {
        
    }

    public function getByCodeBooking() {
        
    }

}
