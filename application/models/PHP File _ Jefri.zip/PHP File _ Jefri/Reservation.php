<?php

class Reservation extends CI_Controller {

    public function index() {
        
    }

    public function add() {
        
    }

    public function confirmation() {
        
    }

    public function validation() {
        
    }

}
