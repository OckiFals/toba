<?php

class Ticket extends CI_Controller {

    public function printt() {
        
    }

    public function validate() {
        
    }

}
