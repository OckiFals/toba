<?php
class PaymentModel extends CI_Model{
    public function getAll(){
        
    }
    public function getByYear(){
        
    }
    public function getByMonth(){
        
    }
}
