<?php

class BusModel extends CI_Model {

    public function getAll() {
        
    }

    public function search() {
        
    }

    public function create() {
        
    }

    public function delete() {
        
    }

    public function update() {
        
    }

    public function getByPK() {
        
    }

}
