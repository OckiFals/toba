<?php

class Schedule extends CI_Controller{

    public function index() {
        
    }

    public function search() {
        
    }

    public function add() {
        
    }

    public function edit() {
        
    }

    public function delete() {
        
    }

}
