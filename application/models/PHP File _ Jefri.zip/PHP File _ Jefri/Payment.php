<?php

class Payment extends CI_Controller {

    public function indext() {
        
    }

    public function sumByYear() {
        
    }

    public function sumByMonth() {
        
    }

}
