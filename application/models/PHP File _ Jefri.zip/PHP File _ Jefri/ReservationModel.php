<?php

class ReservationModel extends CI_Model {

    public function getByBookingCode() {
        
    }

    public function create() {
        
    }

    public function validate() {
        
    }

    public function confirm() {
        
    }

}
