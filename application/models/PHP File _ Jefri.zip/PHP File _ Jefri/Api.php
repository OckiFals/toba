<?php

class Api extends CI_Controller {

    public function bus() {
        
    }

    public function schedule() {
        
    }

}
