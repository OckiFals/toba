<?php

class ScheduleModel extends CI_Model {

    public function getAll() {
        
    }

    public function create() {
        
    }

    public function getByBusname() {
        
    }

    public function update() {
        
    }

    public function delete() {
        
    }

}
