<?php

class AccountModel extends CI_Model {

    public function getAll() {
        
    }

    public function getByPK() {
        
    }

    public function getByName() {
        
    }

    public function create() {
        
    }

    public function update() {
        
    }

    public function delete() {
        
    }

}
