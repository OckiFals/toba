<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Site extends CI_Controller {
	
	public function __construct() {
        parent::__construct();
        # $this->load->helper(array('form', 'url'));
        # $this->load->database();
        # $this->load->model('Lat5_model');
    }

    public function index() {
        echo 'halaman utama Site';
    }

    public function login() {
        echo 'halaman login';
    }

    public function logout() {
        echo 'halaman logout';
    }

    public function search() {
        echo 'halaman pencarian';
    }

    public function reservation() {
        echo 'halaman reservasi';
    }

}